# Crazy Chicken: Road Survival — Offline PWA

## Files
- `index.html` — your game, updated for installable app behavior
- `manifest.json` — app name, icon, and display settings
- `sw.js` — caches the game so it can run offline after first load
- `icons/` — app icons for Android and iPhone

## Publish it (one-time internet connection required)
1. Create a GitHub account if you do not already have one.
2. Create a new public repository, for example `crazy-chicken`.
3. Upload **all files and the `icons` folder** from this package. Keep the folder structure unchanged.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Open the published HTTPS address on your phone.

## Install on phones
- Android (Chrome): open the published link, tap the browser menu, then **Install app** or **Add to Home screen**.
- iPhone (Safari): open the published link, tap **Share**, then **Add to Home Screen**.

## Offline test
Open the published game once while online and wait for it to finish loading. Then close it, turn on Airplane Mode, and launch it from the home-screen icon.

The game itself is self-contained and does not load external images, scripts, or fonts. Offline play begins after the first successful online visit/install. The first visit needs internet because the browser must download the game and its offline cache.
